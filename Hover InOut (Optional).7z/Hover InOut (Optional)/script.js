






$('img').hover(function() {
    $(this).attr('src','elfhat.png');
},function(){
    $(this).attr('src','santahat.png');
}
);












